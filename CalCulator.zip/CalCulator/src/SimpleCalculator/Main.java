package SimpleCalculator;

public class Main {
    public static void main(String args[]){
        Calculator cal = new Calculator();
        cal.setComponent();
        // System.out.println(cal.infixToPostfix("38+91*80"));
        // System.out.println(cal.solvePostfix("38,91,80,*,+"));
        // System.out.println(cal.solvePostfix("38,9114,/"));
    }
}
